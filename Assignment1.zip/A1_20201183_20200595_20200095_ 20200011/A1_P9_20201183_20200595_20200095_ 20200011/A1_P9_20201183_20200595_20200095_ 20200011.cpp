#include <iostream>
#include <algorithm>
#include "time.h"
#include <iomanip>
using namespace std;
class Sorter{

 public:
     int *arr;
     int siize;
     Sorter(){
         arr=0;
         siize=0;
     };
     Sorter(int *arr, int n=0){
         n= sizeof(*arr);
         arr= new int(n);
         siize= n;
     };
     virtual void sort(int *arr ,int n){
         cout<<"im at sorter"<<endl;

     };
     ~Sorter (){
         delete arr;
         siize=0;
     }


 };
void swap(int*a,int*b){
    int t=*a;
    *a=*b;
    *b=t;
}
class selection_sorter: public Sorter{

 public:
    selection_sorter():Sorter(){
        arr=0;
        siize=0;
    };
    selection_sorter(int *an,int n):Sorter( an, n){

    };
     void sort(int *arr, int n){
         cout<<"we are using selection sort"<<endl;
         for (int step = 0; step < n - 1; step++) {
         int min_idx = step;
         for (int i = step + 1; i < n; i++) {


         if (arr[i] < arr[min_idx])
         min_idx = i;
                 }


        swap(&arr[min_idx], &arr[step]);
        }
         //cout<<" Selection sort result"<<endl;
         for(int i=0;i<n;i++){
             cout<<arr[i]<<" ";
         }
         //cout<<endl;

     };
 };
int partition(int arr[], int start, int end)
{

    int pivot = arr[start];

    int count = 0;
    for (int i = start + 1; i <= end; i++) {
        if (arr[i] <= pivot)
            count++;
    }

    int pivotIndex = start + count;
    swap(arr[pivotIndex], arr[start]);

    int i = start, j = end;

    while (i < pivotIndex && j > pivotIndex) {

        while (arr[i] <= pivot) {
            i++;
        }

        while (arr[j] > pivot) {
            j--;
        }

        if (i < pivotIndex && j > pivotIndex) {
            swap(arr[i++], arr[j--]);
        }
    }

    return pivotIndex;
}
void quickSort(int arr[], int start, int end)
{

    if (start >= end)
        return;


    int p = partition(arr, start, end);


    quickSort(arr, start, p - 1);

    quickSort(arr, p + 1, end);
}
class Quick_sorter:public Sorter{
 public:
    Quick_sorter():Sorter(){
        arr=0;
        siize=0;
    };
    Quick_sorter(int *arr, int s): Sorter(arr,s){};
     void sort(int *arr, int siize){
         cout<<"we are using quick sort"<<endl;
         int low;
         int high;
         low= 0;
         high= siize-1;
         quickSort(arr,low,high);
         //cout<<" Quick  sort result"<<endl;
         for(int i=0;i<siize;i++){
             cout<<arr[i]<<" ";
         }
         //cout<<endl;

     };
 };

 class  Testbed{
 public:
     Sorter a;
     Testbed(){};
     Testbed(Sorter a){
     };
     int *Generate_random_list(int minn,int maxx,int sizee ){
         int *arry;
         arry= new int [sizee];
         for (int i=0; i<sizee;i++) {
             arry[i]= minn+(rand()%maxx);

         }
         //cout<<"generating random numbers.... "<<endl;
         for(int i=0;i<sizee;i++){
          cout<<arry[i]<<" ";
         }
         cout<<endl;

         return arry;

     }

     int *reverse_order_list(int minn,int maxx ,int sizee){
         int *revesee;
         revesee= Generate_random_list(minn,maxx,sizee);
         sort(revesee,revesee+sizee,greater<int>());
         cout<<endl;
         cout<<"printing reversed sorted list"<<endl;
         for(int i=0 ;i<sizee;i++){
             cout<<revesee[i]<<" ";
         }
         cout<<endl;

         return revesee;

     }


     double Run_once(Sorter *a, int *arr ,int sizee){
         //cout<< "please enter a range for your arry";
        // int minnn,maxxx;
        // cin>> minnn>>maxxx;
         arr= Generate_random_list(1,1000,sizee);
         clock_t start,end;
         start= clock();
         a->sort(arr,sizee);
         end=clock();
         double timee=double (end-start)/ double (CLOCKS_PER_SEC);
         cout<<endl;
         cout<<"Time taken is "<<fixed<<timee<<setprecision(5);
         cout<<"sec"<<endl;
         cout<<endl;
         return timee;
     }
     double Run_and_avarge(Sorter *d,string t, int minn,int maxx,int size, int nums ){
         double sum=0;
         double *arrrr;
         arrrr= new double[nums];
         for(int i=0;i<nums;i++){
             arrrr[i]=Run_once(d,d->arr,d->siize);
         }
         for(int i=0;i<nums;i++){
             sum=sum+arrrr[i];
         }
         double av;
         av=sum/nums;
         cout<<"The total avarge time is "<<fixed<<av<<setprecision(5) <<" for "<<t<<" values";
         cout<<" sec"<<endl;
         return av;
     }

     void run_exp(Sorter *f, string t,int minn, int maxx ,int minval,int maxval,int setnum,int steps){
         //cout<<"enter type"<<endl;
         //cin>>t;
         t="random";
         int *sizze;
         double *tiiime;
         sizze=new int[100];
         tiiime=new double[100];
         int counter=0;


          int temp=minval;

         for(int i=0;i<setnum;i++){

             //cout<<"temp "<<temp;


             double timeeee=Run_and_avarge(f,t,minn,maxx,temp,setnum);
             temp=temp+steps;

             sizze[counter]=temp;
             tiiime[counter]=timeeee;
             counter++;


         }
         cout<< setw(5)<<"The size"<< "  "<<setw(5)<<"the time"<<endl;
         for (int i=0;i<counter;i++){
         cout<< setw(5)<<sizze[i]<<"     "<<setw(5)<< tiiime[i]<<endl;
         }
     }

 };

 int main(){


     /*int *p;

     p= Generate_random_list(3,77,8);
     for(int i=0;i<8;i++){
         cout<<*(p+i)<<"   ";
     }
     cout<<endl;
     int *r;
     r= reverse_order_list(4,777,6);
     for(int i=0;i<6;i++){
         cout<<*(r+i)<<"   ";
     }
     //int a[8]={6,8,3,2,5,4,1,99};

     //Sorter *A;
     //selection_sorter j;
     //A=&j;
    // A->sort(a,8);

    // Sorter d(a,8);
     //d.sort(a,8);
     //Sorter g;
     //for(int i=0;i<8;i++){
       //  cout<<a[i]<<" ";
     //}*/
     Testbed E;
     Sorter *Q = new Quick_sorter;
     Sorter *S= new selection_sorter;
     //int a[7]={77,55,6,7,8,33,44};
     //s->sort(a,7);
     //l->sort(a,7);
     cout<<"testing first fun (generating random list)"<<endl;
     E.Generate_random_list(7,88,5);
     cout<<"testing the second function (generate random revered list)"<<endl;
     E.reverse_order_list(5,5000,9);
     cout<<"testing the 3rd fun (Run once)"<<endl;
     cout<<"For quick sort"<<endl;

     E.Run_once(Q,Q->arr,8);
     cout<<"For selection sort"<<endl;
     E.Run_once(S,S->arr,8);

     cout<<"Testing 4th function"<<endl;
     cout<<"testing for quick sort"<<endl;
     E.Run_and_avarge(Q,"random",5,99,7,3);
     cout<<"testing for selection sort"<<endl;
     E.Run_and_avarge(S,"random",6,88,6,3);

    cout<<"Testing 5th function"<<endl;
     cout<<"testing for quick sort"<<endl;
     E.run_exp(Q,"random",10,1000,5000,50000,5,5000);
     cout<<"for Quick sort"<<endl;
     cout<<"testing for selection sort"<<endl;
     E.run_exp(S,"random",10,1000,5000,50000,5,5000);
     cout<<"for selection sort"<<endl;

 };
