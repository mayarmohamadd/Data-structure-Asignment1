#include <iostream>
#include<chrono>
#include <algorithm>
using namespace std;
using namespace std::chrono;
int binarySearsh(int arr[],int size,int value){
    int Low=0;
    int high=size-1;
    while (Low<=high)
    {
        int mid=(Low+high)/2;
        if(arr[mid]==value)
        {
            return mid;

        }
        else if(arr[mid]<value)
            Low=mid+1;
        else
            high=mid-1;

    }
    return -1;
}
int  linear_sort(int arr[],int n,int n_elemnt)
{
    for(int i=0;i<n;i++)
    {
        if(arr[i]==n_elemnt)
            return i;
    }
    return -1;
}


void original_insertion(int a[],int size)
{
    int n,new_elemnt,new_position;
    for(int i=1;i<size;i++)
    {
        n=i-1;
        new_elemnt=a[i];
        new_position=binarySearsh(a,size,new_elemnt);
        for(int n=i-1;n>=new_position;n--)
        {
            a[n+1]=new_elemnt;
        }
    }
}
void  binary_sort(int* arr,int N)
{
    int new_elemnt;


    for(int i=1;i<N;i++)
    {
        int n=i;
        new_elemnt=arr[i];
        for(int n=1;n>0&&new_elemnt<arr[n-1];n--)
        {
            arr[n]=arr[n-1];
        }
        arr[n]=new_elemnt;
    }
}
int main()
{
    for(int i=0;i<4;i++)
    {
        int* rr;
        int n;
        auto a =[]() ->int {return rand()%1000;};
        cin>>n;
        rr=new int[n];
        generate(rr,rr+n,a);

        auto start=std::chrono::high_resolution_clock::now();
      //  original_insertion(rr,n);
         binary_sort(rr,n);

        auto stop=std::chrono::high_resolution_clock::now();
        auto duration= duration_cast<microseconds>(stop-start);
        cout<<duration.count()<<"microsecond"<<endl;

    }
}
