#include <iostream>
#include<string>
#include<vector>
#include <algorithm>
using namespace std;
class StudentName
{
private:
    string stName;
public:
    //empty constructors!!
    StudentName(){}
    //paramaterized constructor!!
    StudentName(string name)
    {
         int no_space=0 ,p_last=0;
        for(int i=0;i<name.length();i++)
        {
             if(name[i]==' ')
             {
                 ++no_space;
                 p_last=i;
             }
        }
         if(no_space<2)
         {
             if(no_space==0)
                    stName=name+" "+name+" "+name;
                else
                stName=name+name;
         }
         else
            stName=name;
    }
    //print function!!
    void print()
    {
        vector <string> N;
        string n="";
        for (int i = 0; i < stName.size(); i++){
          if (stName[i] == ' ') {
                N.push_back(n);
                n = "";
            }
          else if(i==stName.length()-1)
          {
              n+=stName[i];
              N.push_back(n);
          }
            else {
                n += stName[i];
            }
        }
        int c=1;
        for(int i=0;i<N.size();i++)
        {
            cout<<c<<")"<<N[i]<<endl;
            c++;
        }
    }
    //function replace return true if i,j in range!!
    bool replace(int i,int j){
        vector <string> N;
        string n="";
        for (int i = 0; i < stName.size(); i++){
            if(i==stName.length()-1)
            {
                n+=stName[i];
                N.push_back(n);
            }
            if (stName[i] == ' ') {
                N.push_back(n);
                n = "";
            }
            else {
                n += stName[i];
            }
        }
        //check if i,j in range or not!
        if(i>N.size()||j>N.size()){
            cout<<"i and j out of range\n";
            cout<<endl;
            return false;
        }
        //swap two element!
        else{
            string temp=N[i-1];
            N[i-1]=N[j-1];
            N[j-1]=temp;
            string new_name;
            for(int i=0;i<N.size();i++){
                new_name+=N[i]+" ";
            }
            cout<<new_name<<endl;
            return true;
        }
    }
};

int main()
{
    //first test!!
    StudentName n("aya ali ahmed sayed");
    cout<<"First test is:\n";
    cout<<"------------------\n";
        if(n.replace(1,3)){
            n.print();
            cout<<"\n";
        }

    //second test!!
    StudentName n2("aya ali ahmed sayed");
        cout<<"Second test is:"<<endl;
        cout<<"------------------\n";
        if(n2.replace(2,3)){
            n2.print();
            cout<<endl;
        }
    //third test!!
    StudentName n3("aya ali ahmed sayed");
    cout<<"Third test is:"<<endl;
    cout<<"------------------\n";
    if(n3.replace(1,5)){
        n3.print();
        cout<<endl;
    }
    //fourth test!!
    StudentName n4("ahmed hassan ali");
    cout<<"Fourth test is:"<<endl;
    cout<<"------------------\n";
    if(n4.replace(1,2)){
        n4.print();
        cout<<endl;
    }
    //fifth test!!
    StudentName n5("ahmed hassan ali");
    cout<<"Fifth test is:\n";
    cout<<"------------------\n";
    if(n5.replace(3,1)){
        n5.print();
        cout<<"\n";
    }
    //sixth test!!
    StudentName n6("ahmed hassan ali");
    cout<<"Sixth test is:\n";
    cout<<"------------------\n";
    if(n6.replace(7,1)){
        n6.print();
        cout<<"\n";
    }
    return 0;
}
