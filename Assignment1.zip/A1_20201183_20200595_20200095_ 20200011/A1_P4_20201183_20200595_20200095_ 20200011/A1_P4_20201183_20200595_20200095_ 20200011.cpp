#include <iostream>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

void RecPermute(string soFar, string rest)
{
    int size;
    //use s;et because the element inside are nuique and sorted
   set<string> arrRay;
if (rest == "")  // No more characters
cout << soFar << endl; // Print the word

 // For each remaining char
for (int i = 0; i < rest.length(); i++) {
string next = soFar + rest[i]; // Glue next char
string remaining = rest.substr(0, i)+ rest.substr(i+1);

 size=arrRay.size();
arrRay.insert(next);

if(arrRay.size()>size)
{RecPermute(next, remaining);}


}
}
// "wrapper" function
void ListPermutations(string s) {
RecPermute("", s);
}

int main()
{
    string a;
    cout<<"Enter a string: "<<endl;
    cin>>a;
    //use the function to sure that is work
    ListPermutations(a);

    return 0;
}
