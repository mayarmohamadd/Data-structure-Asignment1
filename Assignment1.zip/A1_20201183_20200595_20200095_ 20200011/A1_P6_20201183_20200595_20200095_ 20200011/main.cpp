#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include"time.h"
using namespace std;
struct person{
    string firstName;
    string lastName;
    int phone;
};
vector<person>v;
class phoneDirectory{
private:
public:
    //empty constructor!!
    phoneDirectory(){}
//function that Delete an entry by first name.!
    void deleteEntity(string per){
        for(int i=0;i<v.size();i++){
            if(v[i].firstName==per){
                v.erase(v.begin() + i);
            }
        }
    }
    //insert data in phone directory!!
    void insertEntity(person p){
        v.push_back(p);
    }
    //function to Lookup an entry by first name!!
    void serarchByFrN(string fn){
        for(int i=0;i<v.size();i++){
            if(v[i].firstName==fn){
                cout<<"First name is: "<<v[i].firstName<<endl;
                cout<<"Last name is: "<<v[i].lastName<<endl;
                cout<<"Phone number is: "<<v[i].phone<<endl;
            }
        }
    }
    //function to search entity br phone number!!
    void serarchByPh(int pho){
        for(int i=0;i<v.size();i++){
            if(v[i].phone==pho){
                cout<<"First name is: "<<v[i].firstName<<endl;
                cout<<"Last name is: "<<v[i].lastName<<endl;
                cout<<"Phone number is: "<<v[i].phone<<endl;
            }
        }
    }
    //Display function!!
    void print(){
        for (int i = 0; i < v.size(); i++)
        {
            cout <<"First name: "<< v[i].firstName << "      "<<
            "Last name: "<< v[i].lastName << "       "<<
            "Phone number: "<< v[i].phone << endl;
         }
    }
    //insertion sort!!!
    void insertionSort(vector<person>&v) {
        int i, j;
        person tmp;
        for (i = 1; i < v.size(); i++) {
            j = i;
            while (j > 0 && v[j - 1].firstName > v[j].firstName) {
                tmp = v[j];
                v[j] = v[j - 1];
                v[j - 1] = tmp;
                j--;
            }
        }
    }
    //shellSorting!!
    void shell_sort(vector<person>&v){
        for(int gap=v.size()/2;gap>0;gap/=2){
            for(int i=gap;i<v.size();i++){
                person temp=v[i];
                int j;
                for(j=i;j>=gap&&v[j-gap].firstName>temp.firstName;j-=gap){
                    v[j].firstName=v[j-gap].firstName;
                    v[j].lastName=v[j-gap].lastName;
                    v[j].phone=v[j-gap].phone;
                }
                v[j].firstName=temp.firstName;
                v[j].lastName=temp.lastName;
                v[j].phone=temp.phone;

            }
        }
    }
    //selection sort!
    void selectionSort(vector<person>&v) {
    int i, j, minIndex;
    person tmp;
    for (i = 0; i < v.size(); i++) {
        minIndex = i;
        for (j = i + 1; j < v.size(); j++)
            if (v[j].firstName < v[minIndex].firstName)
                minIndex = j;
            if (minIndex != i) {
                tmp = v[i];
                v[i] = v[minIndex];
                v[minIndex] = tmp;
            }
    }
}
};
int main() {
    int num;
    bool mode=true;
    phoneDirectory p;
    person m;
    while(mode== true)
    {
        cout<<"1. Add an entry to the directory\n"
              "2. Look up a phone number\n"
              "3. Look up by first name\n"
              "4. Delete an entry from the directory\n"
              "5. List All entries in phone directory\n"
              "6. Exit form this program\n";
        cout<<"--------------------------------------------------\n";
        cout<<"Enter your choice number \n";
        cin>>num;
        if(num==1){
           cout<<"Enter first name:";
           cin>>m.firstName;
           cout<<"Enter last name:";
           cin>>m.lastName;
           cout<<"Enter phone number:";
           cin>>m.phone;
           p.insertEntity(m);
           //p.print();
        }
        else if(num==2){
            cout<<"Enter search phone number:";
            cin>>m.phone;
            cout<<endl;
            p.serarchByPh(m.phone);
            cout<<endl;
        }
        else if(num==3){
            cout<<"Enter search first name: ";
            cin>>m.firstName;
            cout<<"\n";
            p.serarchByFrN(m.firstName);
            cout<<"\n";
        }
        else if(num==4){
                cout<<"Enter first name to delete this entity:";
                cin>>m.firstName;
                p.deleteEntity(m.firstName);
                //p.insertionSort(v);
                p.print();
                cout<<"\n";
        }
        else if(num==5){
            p.insertionSort(v);
            p.print();
            cout<<endl;
           // p.selectionSort(v);
           // p.shell_sort(v);
            //p.print();
        }
        else if(num==6){
            mode=false;
        }
        else{
           cout<< "Invalid input enter number again between 1 and 6 ,PLZ\n";
           cout<<endl;
        }

    }
    return 0;
}
