#include <bits/stdc++.h>

using namespace std;

template<class T> class linkedList {
public:
    class itr {
    public:
        int item;
        itr *next;

        itr &operator++() {
            this = this->next;
            return *this;
        }

        itr &operator--() {
            this = this->next;
            return *this;
        }

        int operator*() {
            return this->item;
        }

        bool operator==(const itr &right) {
            return item == right.item;
        }
    };

    itr *first;
    itr *last;
    int length;

    itr firstItr() const {
        return *first;
    }

    itr lastItr() const {
        return *last;
    }


    //create default constructor
    linkedList() {
        first = last = nullptr;
        length = 0;
    }

    bool isEmpty() const {
        return length == 0;
    }

    //create function to insert element at beginning of the list
    void insertFirst(int element) {
        itr *newItr = new itr;
        newItr->item = element;
        if (length == 0) {
            first = last = newItr;
            newItr->next = nullptr;
        } else {
            newItr->next = first;
            first = newItr;
        }
        length++;
    }

    //create function to insert element at the end of the list
    void insertLast(int element) {
        itr *newNode = new itr;
        newNode->item = element;
        if (length == 0) {
            first = last = newNode;
            newNode->next = nullptr;
        } else {
            last->next = newNode;
            newNode->next = nullptr;
            last = newNode;
        }
        length++;
    }

    //create function that insert element to specific index
    void insertAtPosition(int pos, int element) {
        if (pos < 0 || pos > length)
            cout << "can't insert the element at this position" << endl;

        else {
            itr *newNode = new itr;
            newNode->item = element;

            if (pos == 0)
                insertFirst(element);

            else if (pos == length)
                insertLast(element);

            else {
                itr *cur = first;
                for (int i = 1; i < pos; i++) {
                    cur = cur->next;
                }
                newNode->next = cur->next;
                cur->next = newNode;
                length++;
            }
        }
    }

    //create function to remove first element in the list
    void removeFirst() {
        if (length == 0) {
            cout << "Empty List Can't remove" << endl;
        } else if (length == 1) {
            delete first;
            last = first = nullptr;
            length--;
        } else {
            itr *cur = first;
            first = first->next;
            delete cur;
            length--;
        }
    }

    //create function to remove last element in the list
    void removeLast() {
        if (length == 0) {
            return;
        } else if (length == 1) {
            delete first;
            last = first = nullptr;
            length--;
        } else {
            itr *cur = first->next;
            itr *prev = first;
            while (cur != last) {
                prev = cur;
                cur = cur->next;
            }
            delete cur;
            prev->next = nullptr;
            last = prev;
            length--;
        }
    }

    //create function to print all items of list
    void print() const {
        itr *cur = first;
        while (cur != nullptr) {
            cout << cur->item << endl;
            cur = cur->next;
        }
    }


    //create a destructor to delete the list
    ~linkedList() {
        itr *cur = first;
        while (cur != nullptr) {
            itr *next = cur->next;
            delete cur;
            cur = next;
        }
        first = nullptr;
    }
};

int main() {

    linkedList<int> ll;

    ll.insertFirst(10);

    ll.insertLast(20);

    ll.insertAtPosition(2, 30);

    ll.insertAtPosition(3, 40);

    ll.insertAtPosition(4, 50);

    ll.print();

    ll.removeFirst();

    ll.removeLast();

    cout << ll.length << endl;

    return 0;
}
