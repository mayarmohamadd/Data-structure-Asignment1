#include<iostream>
#include "fraction.h"
#include "fractionCalculator.h"
using namespace std;
int main(){
   fractionCalculator f;
   f.calculate();
}