using namespace std;
#ifndef PROB2_FRACTIONCALCULATOR_H
#define PROB2_FRACTIONCALCULATOR_H
#include "fraction.h"
class fractionCalculator{
private:
public:
    //default constructure!!
    fractionCalculator(){}
    //void function do calculate!!
    void calculate();
};


#endif //PROB2_FRACTIONCALCULATOR_H
